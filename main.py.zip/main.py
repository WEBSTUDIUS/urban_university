someStr = 'Some string'
print(len(someStr))

first = 10
second = 15
summa = first + second
diff = first - second
print(summa, diff)

l = [10, 15, 25]
first = l[0]
second = l[1]
third = l[2]
mean = (first + second + third) / len(l)
print(mean)

first_string = 'Вторник'
second_string = 'Понедельник'
print(second_string + ', ' + first_string)

a = 5
b = 7
c = 9
f = (((a * b) + (a * c)) ** 2) / 2
print(f)
